using CMS.Scheduler;
using CMS.EventLog;
using CMS;

using System;
using CMS.DataEngine;
//using CMS.DocumentEngine;
//using CMS.Ecommerce;
//using CMS.Helpers;
using CMS.IO;
//using CMS.Membership;
using CMS.CustomTables;
using System.Data;

using CMS.SiteProvider;


[assembly: RegisterCustomClass("Custom.CustomTaskDistrictRouting", typeof(Custom.CustomTaskDistrictRouting))]
namespace Custom
{
	/// <summary>
	/// Custom task class.
	/// </summary>
	public class CustomTaskDistrictRouting: ITask
	{
		/// <summary>
		/// Executes the task.
		/// </summary>
		/// <param name="ti">Info object representing the scheduled task</param>
		public string Execute(TaskInfo ti)
		{
			string detail = "This is a test. Executed from '~/App_Code/CustomTaskDistrictRouting.cs'. Task data:" + ti.TaskData;

			// Logs the execution of the task in the event log.

			FileStream file = null;
			string customTableClassName = "customtable.DistrictClaimRouting";
			DataClassInfo customTable = DataClassInfoProvider.GetDataClassInfo(customTableClassName);
			CustomTableItemProvider.DeleteItems(customTableClassName, null);

			try
			{
				
				file = FileStream.New("C:/inetpub/kentroot/TASB/CMS/Imports/DistrictRouting.csv", FileMode.Open, FileAccess.Read);

				var reader = StreamReader.New(file);
				int lineCount = 0;
				while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
					if(lineCount++>0)
					{
						if (line != null && line.Trim() != "")
						{
							string[] d = line.Trim().Split(',');

							if (customTable != null)
							{
								// Creates a new custom table item
								CustomTableItem newCustomTableItem = CustomTableItem.New(customTableClassName);

								// Sets the values for the fields of the custom table (ItemText in this case)
								
								newCustomTableItem.SetValue("DistrictName", d[0]);
								newCustomTableItem.SetValue("RoutingURL", d[1]);
								
								// Save the new custom table record into the database
								newCustomTableItem.Insert();
							}						
						}						
					}

				}
				reader.Dispose();
			}
			catch (Exception ex)
			{
				//error = "Error loading file '" + filePath + "': " + ex.Message;
				EventLogProvider.LogInformation("CustomTaskDistrictRouting", "Execute", ex.Message);
			}

			return null;
		}
	}
}