						(function () {
            "use strict"
			 let arrowSelectedDistrict;
            let activeIndex = 0;
            window.addEventListener('click', (event) => {
                if (event.target !== document.querySelector('.district')) {
                    closeAutocomplete();
                }
            });
            window.addEventListener('keydown', (event) => {
                const districts = document.querySelectorAll(".autocomplete-items div");
                if (districts && districts.length) {
                    if (event.which === 40) { // Arrow Down
                        if (arrowSelectedDistrict ) {
                            arrowSelectedDistrict.style.backgroundColor = '#fff';
                            ++activeIndex;
                            districts[activeIndex].style.backgroundColor = '#f6cd41';
                            arrowSelectedDistrict = districts[activeIndex];
                            if(activeIndex >= (districts.length - 1)) {
                                arrowSelectedDistrict = null;
                            }
                            scrollIntoViewIfNeeded(districts[activeIndex]);
                        } else {
                            activeIndex = 0;
                            districts[activeIndex].style.backgroundColor = '#f6cd41';
                            arrowSelectedDistrict = districts[activeIndex];
                        }
                    } else if (event.which === 38) { // Arrow Up
                        if (arrowSelectedDistrict) {
                            arrowSelectedDistrict.style.backgroundColor = '#fff';
                            --activeIndex;
                            districts[activeIndex].style.backgroundColor = '#f6cd41';
                            arrowSelectedDistrict = districts[activeIndex];
                            if(activeIndex <= 0) {
                                arrowSelectedDistrict = null;
                            } 
                            scrollIntoViewIfNeeded(districts[activeIndex]);
                        } else {
                            console.log(activeIndex)
                            for(let district of districts) {
                                district.style.backgroundColor = '#fff';
                            }
                            activeIndex = districts.length - 1;
                            districts[activeIndex].style.backgroundColor = '#f6cd41';
                            arrowSelectedDistrict = districts[activeIndex];
                        }
                    }
                }
            });
            document.querySelector('#btnSubmit').addEventListener("click", (e) => {
                const selectedDistrict = document.querySelector('.inputbox').value;
                if (selectedDistrict) {
                    const foundDistrict = JSON.parse(districtData).routingURLs.find(dc => dc.district.toLowerCase() === selectedDistrict.toLowerCase());
                    if (foundDistrict && foundDistrict.destination) {
						console.log(foundDistrict.destination);
                        window.open(foundDistrict.destination, '_blank');
                    }
                }
            });
			
            document.querySelector('#district').addEventListener("input", (e) => {
                const input = e.target;
                closeAutocomplete();
                if (!input.value) {
                    return false;
                }
                const dcData = JSON.parse(districtData).routingURLs.map(dc => dc.district);
				// console.log(typeOf.JSON.parse(JSON.parse(districtData)));
                let autoCompleteElement = document.createElement("DIV");
                autoCompleteElement.setAttribute("id", e.target.id + "autocomplete-list");
                autoCompleteElement.setAttribute("class", "autocomplete-items");
                input.parentNode.appendChild(autoCompleteElement);
                for (var i = 0; i < dcData.length; i++) {
                    if (dcData[i].toUpperCase().includes(input.value.toUpperCase())) {
                        let matchedElement = document.createElement("DIV");
                        matchedElement.innerHTML = dcData[i];
                        matchedElement.innerHTML += "<input type='hidden' value='" + dcData[i] + "'>";
                        matchedElement.addEventListener('click', (e) => {
                            input.value = e.target.querySelector('input').value;
                            closeAutocomplete();
                        });
                        autoCompleteElement.appendChild(matchedElement);
                    }
                }
            });
            
            function closeAutocomplete(element) {
                const autoCompleteItems = document.getElementsByClassName("autocomplete-items");
                for (let i = 0; i < autoCompleteItems.length; i++) {
                    if (element !== autoCompleteItems[i] && element !== document.querySelector('#district')) {
                        autoCompleteItems[i].parentNode.removeChild(autoCompleteItems[i]);
                    }
                }
            }
            function scrollIntoViewIfNeeded(target) {
                var rect = target.getBoundingClientRect();
                if (rect.bottom > 140) {
                    target.scrollIntoView(false);
                }
                if (rect.top < 0) {
                    target.scrollIntoView();
                }
            }
        })()